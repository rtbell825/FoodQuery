# FoodQuery
Nicolas Mewhirter : mewhirter@wisc.edu | X-Team 85


Ryan Bell: rtbell@wisc.edu | X-Team 85


Harrison Colcord: colcord@wisc.edu | X-Team 85


Andrew Harron: aharron@wisc.edu | X-Team 03
